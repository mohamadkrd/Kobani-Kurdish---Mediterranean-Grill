<?php
session_start();
include('connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<section>
    <?php include('header.php'); ?>
</section>
<section id="home">
    <img src="assets/img/kobani_banner.png" id="banner">
</section>
<section id="red-button-section">
    <a href="order.php" style="text-decoration: none;">
        <button id="red-button">
            <h1>
                ORDER NOW
            </h1>
        </button>
    </a>
</section>
<section>
    <img src="assets/img/art.png" alt="art">
</section>
<section>
    <?php include('footer.php'); ?>
</section>
</body>
</html>
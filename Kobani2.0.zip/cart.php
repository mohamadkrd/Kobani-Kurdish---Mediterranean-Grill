<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<section>
    <?php include('header.php'); ?>
</section>
<div>

    <?php
    session_start();
    include('connection.php');

    function getProductDetails($productId) {
        global $conn;
        $sql = "SELECT * FROM producten WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    if (isset($_SESSION['cart'])) {
        echo "<h2>Your Cart:</h2>";
        $totalPrice = 0; t
        foreach ($_SESSION['cart'] as $productId) {
            $product = getProductDetails($productId);
            if ($product) {
                echo "<div>";
                echo '<img src="assets/img/' . $product['Product'] . '.png">';
                if(isset($product['Product']) && isset($product['Price'])) {
                    echo "<h3>" . $product['Product'] . " - € " . $product['Price'] . "</h3>";
                    $totalPrice += $product['Price']; // Add price to total
                } else {
                    echo "Product details not available.";
                }
                if(isset($product['Description'])) {
                    echo "<p>" . $product['Description'] . "</p>";
                } else {
                    echo "Product description not available.";
                }
                echo "</div>";
            }
        }

        echo "<p>Total: € " . $totalPrice . "</p>";
    } else {
        echo "<p>Your cart is empty.</p>";
    }

    function addToCart($productId) {
        $_SESSION['cart'][] = $productId;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['product_id'])) {
            addToCart($_POST['product_id']);
            header('Location: cart.php');
            exit();
        }
    }
    ?>
</div>
<section>
    <img src="assets/img/art.png" alt="art">
</section>
<section>
    <?php include('footer.php'); ?>
</section>
</body>
</html>

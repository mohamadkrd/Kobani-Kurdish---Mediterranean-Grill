<footer>
    <div>
        <h2>
            Make an order by calling our number: 06 123456789
        </h2>
    </div>
</footer>
<?php
include ('../Connection.php');

$sql = "UPDATE product SET omschrijving=:omschrijving WHERE id=:id";
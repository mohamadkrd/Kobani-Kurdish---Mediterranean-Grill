<?php
// Database connection settings
$host = 'localhost';
$dbname = 'kobani';
$username = 'root';
$password = 'Little1314107';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['gebruikersnaam'];
    $email = $_POST['email'];
    $password = $_POST['wachtwoord'];
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $existing_user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_user) {
        $error_message = "Username already in use. Please choose another one.";
    } else {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (username, email, password_hash) VALUES (:username, :email, :passwordHash)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':passwordHash', $passwordHash);
        $stmt->execute();

        header("Location: login.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<section>
    <?php include('header.php'); ?>
</section>
<section id="home">
    <img src="assets/img/kobani_banner.png" id="banner">
</section>
<section id="register-block">
    <div id="home-block">
        <div>
            <h2>Register</h2>
            <form id="form" method="post">
                <?php if (isset($error_message)) { ?>
                    <p style="color: red;"><?php echo $error_message; ?></p>
                <?php } ?>
                <div class="row">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="gebruikersnaam" required>
                </div>
                <div class="row">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="row">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="wachtwoord" required>
                </div>
                <button type="submit" id="submit-button">Register</button>
            </form>
        </div>
    </div>
</section>
<section>
    <img src="assets/img/art.png" alt="art">
</section>
<section>
    <?php include('footer.php'); ?>
</section>
</body>
</html>

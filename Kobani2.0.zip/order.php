<?php
session_start();
include('connection.php');

function addToCart($productId) {
    $_SESSION['cart'][] = $productId;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['product_id'])) {
        addToCart($_POST['product_id']);
        header('Location: cart.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<section>
    <?php include('header.php'); ?>
</section>
<section id="home">
    <img src="assets/img/kobani_banner.png" id="banner">
</section>
<section>
    <div class="uneven-product-box">
        <div class="center">
            <h2> Order now </h2>
        </div>
        <?php
        $sql = "SELECT * FROM producten";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="row">';
                echo '<div class="product-img">';
                echo '<img src="assets/img/' . $row['Product'] . '.png">';
                echo '</div>';
                echo '<div class="product-title">';
                if(isset($row['Product']) && isset($row['price'])) {
                    echo "<h3>" . $row['Product'] . " - € " . $row['price'] . "</h3>";
                } else {
                    echo "Product details not available.";
                }
                echo '</div>';
                echo '<form method="post">';
                echo '<input type="hidden" name="product_id" value="' . $row['id'] . '">';
                echo '<button type="submit"><h3>add to cart</h3></button>';
                echo '</form>';
                echo '</div>';
            }
        } else {
            echo "No products found";
        }
        ?>
    </div>
</section>
<section>
    <img src="assets/img/art.png" alt="art">
</section>
<section>
    <?php include('footer.php'); ?>
</section>
</body>
</html>

<header>
    <section>
        <div id="logo-container">
            <img src="assets/img/kobani_logo.png" alt="Kobani Logo" id="logo">
        </div>
        <div style="width: 260px;">
            <?php
            if(isset($_SESSION['username'])) {
                echo "<h2>Hello, " . $_SESSION['username'] . "!</h2>";
            }
            ?>
        </div>
        <nav>
            <ul>
                <a href="index.php"><li> Home </li></a>
                <a href="order.php"><li> Order now </li></a>
                <a href="cart.php"><li> Cart </li></a>
                <a href="register.php"><li> Register </li></a>
                <a href="login.php"><li> Login </li></a>
            </ul>
        </nav>
    </section>
</header>
